# backend/utils/file_utils.py

import shutil
import os
import uuid
from fastapi import UploadFile

async def save_upload_file_tmp(upload_file: UploadFile) -> str:
    temp_file_id = str(uuid.uuid4())
    folder = "backend/data"
    
    # ✅ Make sure the folder exists even if it was deleted or never created
    os.makedirs(folder, exist_ok=True)

    file_path = os.path.join(folder, f"{temp_file_id}_{upload_file.filename}")
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(upload_file.file, buffer)

    return file_path
