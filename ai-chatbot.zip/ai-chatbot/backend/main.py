from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from routes.chat_routes import router as chat_router
import os

app = FastAPI(
    title="AI Visual Chatbot",
    description="ChatGPT-powered chatbot with data visualization capabilities.",
    version="1.0.0"
)

# Enable CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount the static directory for serving chart images
chart_folder_path = os.path.join(os.path.dirname(__file__), "data")
app.mount("/charts", StaticFiles(directory=chart_folder_path), name="charts")

# Register routes
app.include_router(chat_router, prefix="/api/chat", tags=["Chat"])

@app.get("/")
def read_root():
    return {"message": "AI Visual Chatbot backend is running."}
