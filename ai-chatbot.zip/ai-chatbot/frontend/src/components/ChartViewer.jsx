import { useState } from "react";

export default function ChartViewer({ imageUrl }) {
  const [isOpen, setIsOpen] = useState(false);

  if (!imageUrl) return null;

  return (
    <>
      <img
        src={`http://localhost:8000/charts/${imageUrl}`}
        alt="Chart"
        className="w-48 h-auto rounded-md cursor-zoom-in shadow hover:scale-105 transition-transform"
        onClick={() => setIsOpen(true)}
      />

      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50"
          onClick={() => setIsOpen(false)}
        >
          <img
            src={`http://localhost:8000/charts/${imageUrl}`}
            alt="Full Chart"
            className="max-w-[90vw] max-h-[90vh] border-4 border-white rounded shadow-lg"
          />
        </div>
      )}
    </>
  );
}
