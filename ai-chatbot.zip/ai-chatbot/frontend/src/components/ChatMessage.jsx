import ChartViewer from "./ChartViewer";

export default function ChatMessage({ message }) {
  const isUser = message.type === "user";

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-xs md:max-w-md px-4 py-2 rounded-lg shadow 
          ${isUser ? "bg-blue-500 text-white" : "bg-gray-200 text-black"}
        `}
      >
        <p className="whitespace-pre-line">{message.content}</p>

        {message.imageUrl && (
          <div className="mt-2">
            <ChartViewer imageUrl={message.imageUrl} />
          </div>
        )}
      </div>
    </div>
  );
}
