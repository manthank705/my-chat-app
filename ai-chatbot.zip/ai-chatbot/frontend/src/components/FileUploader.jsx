import { useState } from "react";
import axios from "axios";

export default function FileUploader() {
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState("");

  const handleUpload = async () => {
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    try {
      setStatus("Uploading...");
      await axios.post("http://localhost:8000/api/chat/upload", formData);
      setStatus("✅ File uploaded successfully");
    } catch (error) {
      console.error("File upload failed", error);
      setStatus("❌ Upload failed");
    }
  };

  return (
    <div className="flex items-center gap-2">
      <input
        type="file"
        accept=".csv"
        onChange={(e) => setFile(e.target.files[0])}
        className="border p-1 rounded"
      />
      <button
        className="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700"
        onClick={handleUpload}
      >
        Upload CSV
      </button>
      {status && <span className="text-sm text-gray-600">{status}</span>}
    </div>
  );
}
