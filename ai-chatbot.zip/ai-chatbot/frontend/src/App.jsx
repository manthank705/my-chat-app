import { useState, useRef, useEffect } from "react";
import axios from "axios";
import ChartViewer from "./components/ChartViewer";
import TypingSpinner from "./components/TypingSpinner";

export default function App() {
  const [messages, setMessages] = useState([]);
  const [userInput, setUserInput] = useState("");
  const [file, setFile] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const chatEndRef = useRef(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!userInput.trim()) return;

    setMessages((prev) => [
      ...prev,
      { sender: "user", type: "text", content: userInput },
    ]);
    setUserInput("");
    setIsLoading(true);

    try {
      if (shouldGenerateChart(userInput)) {
        const res = await axios.post(
          "http://localhost:8000/api/chat/generate-chart",
          { prompt: userInput }
        );
        const imageName = res.data.image_url.split("/").pop();
        setMessages((prev) => [
          ...prev,
          { sender: "bot", type: "image", content: imageName },
        ]);
      } else {
        const res = await axios.post(
          "http://localhost:8000/api/chat/ask",
          { message: userInput }
        );
        setMessages((prev) => [
          ...prev,
          { sender: "bot", type: "text", content: res.data.reply },
        ]);
      }
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          sender: "bot",
          type: "text",
          content: "❌ Failed to respond. Please try again.",
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpload = async () => {
    if (!file) return;
    const formData = new FormData();
    formData.append("file", file);
    try {
      await axios.post("http://localhost:8000/api/chat/upload", formData);
      alert("✅ File uploaded successfully.");
    } catch (err) {
      alert("❌ Upload failed.");
    }
  };

  const shouldGenerateChart = (msg) => {
    const keywords = [
      "chart", "graph", "plot", "trend", "sales", "visualize",
      "compare", "distribution", "bar chart", "line chart", "draw", "show"
    ];
    return keywords.some((word) => msg.toLowerCase().includes(word));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-blue-50 p-4 flex flex-col items-center">
      <h1 className="text-4xl font-bold text-blue-800 mb-6 drop-shadow">📊 AI Chart Chatbot</h1>

      {/* Chat Window */}
      <div className="w-full max-w-3xl bg-white rounded-lg shadow-xl p-4 flex flex-col gap-3 h-[70vh] overflow-y-auto">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
          >
            <div className="mb-2">
              <div
                className={`relative max-w-[75%] px-4 py-3 text-sm md:text-base rounded-2xl shadow-sm ${
                  msg.sender === "user"
                    ? "bg-blue-600 text-white rounded-br-none"
                    : "bg-gray-100 text-gray-900 rounded-bl-none"
                }`}
              >
                {msg.type === "image" ? (
                  <ChartViewer imageUrl={msg.content} />
                ) : (
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                )}
              </div>
            </div>
          </div>
        ))}
        {isLoading && <TypingSpinner />}
        <div ref={chatEndRef} />
      </div>

      {/* File Upload */}
      <div className="w-full max-w-3xl mt-5 flex items-center justify-between gap-4 flex-wrap">
        <input
          type="file"
          accept=".csv"
          className="file:border file:px-2 file:py-1 file:rounded file:bg-blue-50 file:text-sm file:border-blue-300"
          onChange={(e) => setFile(e.target.files[0])}
        />
        <button
          className="bg-green-600 text-white px-5 py-2 rounded-lg hover:bg-green-700 transition"
          onClick={handleUpload}
        >
          Upload CSV
        </button>
      </div>

      {/* Input */}
      <div className="w-full max-w-3xl mt-4 flex gap-2">
        <input
          type="text"
          placeholder="Ask something like: Show total sales by year"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
        />
        <button
          className="bg-blue-600 text-white px-5 py-2 rounded-lg hover:bg-blue-700 transition"
          onClick={handleSend}
        >
          Send
        </button>
      </div>
    </div>
  );
}
